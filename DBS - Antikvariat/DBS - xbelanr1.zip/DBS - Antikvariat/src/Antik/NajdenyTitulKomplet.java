package Antik;

public class NajdenyTitulKomplet extends NajdenyTitul {
	String nazovTypu = new String();
	String nazovZanru = new String();
	
	
	public String getNazovTypu() {
		return nazovTypu;
	}
	public void setNazovTypu(String nazovTypu) {
		this.nazovTypu = nazovTypu;
	}
	public String getNazovZanru() {
		return nazovZanru;
	}
	public void setNazovZanru(String nazovZanru) {
		this.nazovZanru = nazovZanru;
	}
	
	
}
