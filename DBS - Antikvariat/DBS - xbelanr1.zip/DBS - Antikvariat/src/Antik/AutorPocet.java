package Antik;

public class AutorPocet {
	private String meno;
	private Integer pocet;
	public String getMeno() {
		return meno;
	}
	public void setMeno(String meno) {
		this.meno = meno;
	}
	public Integer getPocet() {
		return pocet;
	}
	public void setPocet(Integer pocet) {
		this.pocet = pocet;
	}
	
	
}
